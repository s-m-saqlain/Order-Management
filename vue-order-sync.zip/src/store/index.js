import { defineStore } from 'pinia';
import { orders as initialOrders } from '../data.js';

export const useOrderStore = defineStore('orders', {
  state: () => ({
    orders: initialOrders.map(order => ({ ...order, isCompleted: false })),
    searchQuery: '',
  }),
  getters: {
    filteredOrders: (state) => {
      return state.orders.filter(order =>
        (order.orderID.includes(state.searchQuery) ||
         order.customerName.toLowerCase().includes(state.searchQuery.toLowerCase()))
      );
    },
  },
  actions: {
    toggleCompletion(orderId) {
      const order = this.orders.find(o => o.orderID === orderId);
      if (order) order.isCompleted = !order.isCompleted;
    },
    updateSearchQuery(query) {
      this.searchQuery = query;
    },
  },
});