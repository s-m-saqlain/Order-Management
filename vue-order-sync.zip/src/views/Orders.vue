<template>
  <div class="min-h-screen bg-gray-50/50 p-4 md:p-6 lg:p-8">
    <div class="mx-auto max-w-7xl space-y-6">
      <!-- Header Section -->
      <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 class="text-3xl font-bold tracking-tight text-gray-900">Order Management</h1>
          <p class="text-gray-600 mt-1">Manage and track all your orders in one place</p>
        </div>
      </div>

      <!-- Stats Cards -->
      <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm font-medium text-gray-600">Total Orders</p>
              <p class="text-2xl font-bold text-gray-900 mt-1">{{ filteredOrders.length }}</p>
            </div>
            <div class="h-12 w-12 bg-blue-50 rounded-lg flex items-center justify-center">
              <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
              </svg>
            </div>
          </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm font-medium text-gray-600">Fulfilled</p>
              <p class="text-2xl font-bold text-green-600 mt-1">{{ filteredOrders.filter(o => o.orderStatus === 'FULFILLED').length }}</p>
            </div>
            <div class="h-12 w-12 bg-green-50 rounded-lg flex items-center justify-center">
              <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
              </svg>
            </div>
          </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm font-medium text-gray-600">Pending</p>
              <p class="text-2xl font-bold text-yellow-600 mt-1">{{ filteredOrders.filter(o => o.orderStatus === 'UNVERIFIED').length }}</p>
            </div>
            <div class="h-12 w-12 bg-yellow-50 rounded-lg flex items-center justify-center">
              <svg class="h-6 w-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
              </svg>
            </div>
          </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm font-medium text-gray-600">Completed</p>
              <p class="text-2xl font-bold text-blue-600 mt-1">{{ filteredOrders.filter(o => o.isCompleted).length }}</p>
            </div>
            <div class="h-12 w-12 bg-blue-50 rounded-lg flex items-center justify-center">
              <svg class="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/>
              </svg>
            </div>
          </div>
        </div>
      </div>

      <!-- Main Content Card -->
      <div class="bg-white rounded-xl shadow-sm border border-gray-200">
        <!-- Card Header -->
        <div class="px-6 py-5 border-b border-gray-200">
          <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 class="text-xl font-semibold text-gray-900">Orders</h2>
            <!-- Enhanced Search Input -->
            <div class="relative w-full md:w-80">
              <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                </svg>
              </div>
              <input
                v-model="searchQuery"
                type="text"
                placeholder="Search by Order ID or Customer Name..."
                class="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-lg text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-200"
              />
            </div>
          </div>
        </div>

        <!-- Enhanced Table -->
        <div class="overflow-hidden">
          <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
              <thead class="bg-gray-50">
                <tr>
                  <th 
                    class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition duration-200 select-none group" 
                    @click="sort('orderID')"
                  >
                    <div class="flex items-center gap-2">
                      Order #
                      <svg class="h-4 w-4 text-gray-400 group-hover:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"/>
                      </svg>
                    </div>
                  </th>
                  <th 
                    class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition duration-200 select-none group" 
                    @click="sort('orderStatus')"
                  >
                    <div class="flex items-center gap-2">
                      Status
                      <svg class="h-4 w-4 text-gray-400 group-hover:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"/>
                      </svg>
                    </div>
                  </th>
                  <th 
                    class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition duration-200 select-none group" 
                    @click="sort('customerName')"
                  >
                    <div class="flex items-center gap-2">
                      Customer
                      <svg class="h-4 w-4 text-gray-400 group-hover:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"/>
                      </svg>
                    </div>
                  </th>
                  <th 
                    class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition duration-200 select-none group" 
                    @click="sort('purDate')"
                  >
                    <div class="flex items-center gap-2">
                      Purchase Date
                      <svg class="h-4 w-4 text-gray-400 group-hover:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"/>
                      </svg>
                    </div>
                  </th>
                  <th 
                    class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition duration-200 select-none group" 
                    @click="sort('fulfillDate')"
                  >
                    <div class="flex items-center gap-2">
                      Fulfilled Date
                      <svg class="h-4 w-4 text-gray-400 group-hover:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"/>
                      </svg>
                    </div>
                  </th>
                  <th 
                    class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition duration-200 select-none group" 
                    @click="sort('invoiceStatus')"
                  >
                    <div class="flex items-center gap-2">
                      Invoice Status
                      <svg class="h-4 w-4 text-gray-400 group-hover:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"/>
                      </svg>
                    </div>
                  </th>
                  <th 
                    class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition duration-200 select-none group" 
                    @click="sort('amount')"
                  >
                    <div class="flex items-center gap-2">
                      Amount
                      <svg class="h-4 w-4 text-gray-400 group-hover:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"/>
                      </svg>
                    </div>
                  </th>
                  <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                    Action
                  </th>
                </tr>
              </thead>
              <tbody class="bg-white divide-y divide-gray-200">
                <tr 
                  v-for="order in sortedOrders" 
                  :key="order.orderID" 
                  class="hover:bg-gray-50 transition duration-200"
                >
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="text-sm font-semibold text-gray-900">{{ order.orderID }}</div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span 
                      :class="getStatusClass(order.orderStatus)" 
                      class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border"
                    >
                      {{ order.orderStatus }}
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex items-center">
                      <div class="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center mr-3">
                        <span class="text-xs font-medium text-gray-600">{{ order.customerName.charAt(0) }}</span>
                      </div>
                      <div class="text-sm font-medium text-gray-900">{{ order.customerName }}</div>
                    </div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{{ order.purDate }}</td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{{ order.fulfillDate }}</td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span 
                      :class="order.invoiceStatus === 'VERIFIED' ? 'bg-green-50 text-green-700 border-green-200' : 'bg-gray-50 text-gray-700 border-gray-200'" 
                      class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border"
                    >
                      {{ order.invoiceStatus }}
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">
                    {{ order.amount }} {{ order.currency }}
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <button
                      @click="toggleCompletion(order.orderID)"
                      :class="order.isCompleted 
                        ? 'bg-green-50 text-green-700 border-green-200 cursor-not-allowed' 
                        : 'bg-blue-600 text-white border-blue-600 hover:bg-blue-700 hover:border-blue-700'"
                      class="inline-flex items-center px-3 py-1.5 border text-xs font-medium rounded-lg transition duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      :disabled="order.isCompleted"
                    >
                      <svg v-if="order.isCompleted" class="h-3 w-3 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                      </svg>
                      {{ order.isCompleted ? 'Completed' : 'Mark Complete' }}
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <!-- Empty State -->
          <div v-if="filteredOrders.length === 0" class="text-center py-12">
            <svg class="mx-auto h-12 w-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
            </svg>
            <h3 class="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
            <p class="text-gray-500">Try adjusting your search criteria or check back later.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { useOrderStore } from '../store';

export default {
  name: 'Orders',
  computed: {
    filteredOrders() {
      return useOrderStore().filteredOrders;
    },
    searchQuery: {
      get() { return useOrderStore().searchQuery; },
      set(value) { useOrderStore().updateSearchQuery(value); }
    },
    sortedOrders() {
      return [...this.filteredOrders].sort((a, b) => {
        if (this.sortKey) {
          return this.sortDirection * a[this.sortKey].localeCompare(b[this.sortKey]);
        }
        return 0;
      });
    },
  },
  data() {
    return {
      sortKey: null,
      sortDirection: 1,
    };
  },
  methods: {
    toggleCompletion(orderId) {
      useOrderStore().toggleCompletion(orderId);
    },
    sort(key) {
      if (this.sortKey === key) {
        this.sortDirection *= -1;
      } else {
        this.sortKey = key;
        this.sortDirection = 1;
      }
    },
    getStatusClass(status) {
      const classes = {
        'Refunded': 'bg-red-50 text-red-700 border-red-200',
        'Part Refund': 'bg-yellow-50 text-yellow-700 border-yellow-200',
        'FULFILLED': 'bg-green-50 text-green-700 border-green-200',
        'VERIFIED': 'bg-blue-50 text-blue-700 border-blue-200',
        'UNVERIFIED': 'bg-gray-50 text-gray-700 border-gray-200',
      };
      return classes[status] || 'bg-gray-50 text-gray-700 border-gray-200';
    },
  },
};
</script>

<style scoped>
/* Custom styles for enhanced UI */
.table-container {
  @apply overflow-hidden rounded-lg border border-gray-200;
}

/* Smooth transitions for interactive elements */
button, th {
  transition: all 0.2s ease-in-out;
}

/* Enhanced focus states */
input:focus {
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

/* Custom scrollbar for table */
.overflow-x-auto::-webkit-scrollbar {
  height: 6px;
}

.overflow-x-auto::-webkit-scrollbar-track {
  background: #f1f5f9;
  border-radius: 3px;
}

.overflow-x-auto::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 3px;
}

.overflow-x-auto::-webkit-scrollbar-thumb:hover {
  background: #94a3b8;
}
</style>
